// Rename this file to firebase-config.local.js and fill in your Firebase project keys.
// Then include it before db.js in your HTML to enable multi-user real-time sync via Firestore.
// Example:
// <script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-app-compat.js"></script>
// <script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore-compat.js"></script>
// <script src="firebase-config.local.js"></script>
// <script src="db.js"></script>

// window.FIREBASE_CONFIG = {
//   apiKey: "...",
//   authDomain: "...",
//   projectId: "...",
//   storageBucket: "...",
//   messagingSenderId: "...",
//   appId: "..."
// };


