# Digital Khata Book - Order Management System

A modern, responsive web application for managing customer orders and tracking business transactions. This digital khata book provides an intuitive interface for small businesses to maintain their customer order records efficiently.

## 🌟 Features

### 📝 Order Management
- **Add New Orders**: Comprehensive form with customer details, order information, and status tracking
- **Order Tracking**: Real-time view of all orders with filtering and search capabilities
- **Status Updates**: Easy modification of payment and delivery status
- **Data Validation**: Robust form validation to ensure data integrity
- **Item Management**: Add multiple items with automatic bill calculation and tax computation

### 📊 Analytics & Reporting
- **Dashboard Statistics**: Real-time overview of total orders, pending payments, and deliveries
- **Advanced Filtering**: Filter orders by payment status, delivery status, and customer search
- **Excel Export**: Export all orders or filtered results to Excel spreadsheets
- **Data Backup**: Backup and restore functionality for data safety
- **Quick Actions**: Bulk operations for marking orders as paid/delivered

### 🎨 User Experience
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices
- **Modern UI**: Clean, intuitive interface with smooth animations
- **Keyboard Shortcuts**: Quick navigation using keyboard shortcuts
- **Real-time Updates**: Instant feedback and status updates
- **Theme Switching**: Choose between Chinese and Modern themes
- **Offline Support**: Works without internet connection
- **Multi-user Sync (Optional)**: Real-time sync via Firestore when configured

### 🔒 Security Features
- **Input Sanitization**: Protection against XSS attacks
- **Data Validation**: Comprehensive form validation
- **Local Storage**: Secure data storage using browser's localStorage
- **CSRF Protection**: Basic CSRF token implementation

### 🛠️ Advanced Features
- **Settings Management**: Complete data management and backup system
- **Bulk Operations**: Mark all orders as paid/delivered with one click
- **Data Cleanup**: Automatic deletion of old orders (30+ days)
- **Statistics Dashboard**: Detailed data insights and storage information
- **Service Worker**: Offline functionality and caching

## 🚀 Quick Start

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No additional software installation required

### Installation
1. **Download the files** to your local machine
2. **Open `test.html`** to see the test page with sample data
3. **Open `index.html`** in your web browser to start using the application
4. **Start using** the application immediately

### Enable Multi-user (Cloud) Sync
1. Create a Firebase project and enable Firestore (in Native/Compatibility mode)
2. Copy `firebase-config.js` to `firebase-config.local.js` and fill in your Firebase config
3. Include `firebase-config.local.js` before `db.js` in `index.html` and `all_orders.html`
4. Open the app: new orders and changes will sync across all devices automatically

If you skip this setup, the app uses localStorage with lightweight polling so multiple tabs/devices on the same machine still see updates.

### File Structure
```
Digital-Khata-Book/
├── index.html          # Main application file
├── test.html           # Test page with sample data
├── chinese-theme.css   # Chinese theme styling
├── modern-theme.css    # Modern theme styling
├── script.js           # JavaScript functionality
├── sw.js              # Service worker for offline support
├── manifest.json      # PWA manifest
└── README.md          # This documentation
```

## 📖 Usage Guide

### Getting Started
1. **Launch the application** by opening `index.html` in your browser
2. **Add test data** by visiting `test.html` and clicking "Test Features"
3. **Explore the interface** using the four main tabs:
   - **Add Order**: Create new customer orders
   - **Track Orders**: View and manage existing orders
   - **Export to Excel**: Export data for backup/analysis
   - **Settings**: Manage data, themes, and backups

### Adding a New Order
1. Navigate to the "Add Order" tab
2. Fill in the required fields:
   - **Customer Name**: Enter the customer's full name
   - **Order Details**: Describe the items or services ordered
   - **Order Date**: Select the order date (defaults to today)
   - **Items**: Add specific items with quantities (optional)
   - **Payment Status**: Select "Pending" or "Done"
   - **Delivery Status**: Select "Pending" or "Delivered"
3. Click "Save Order" to add the order to your system

### Managing Orders
1. Go to the "Track Orders" tab
2. View the dashboard statistics at the top
3. Use the filters to narrow down orders:
   - **Payment Filter**: Show orders by payment status
   - **Delivery Filter**: Show orders by delivery status
   - **Search**: Find orders by customer name or details
4. Use Quick Actions for bulk operations:
   - **Mark All as Paid**: Update all orders to paid status
   - **Mark All as Delivered**: Update all orders to delivered status
   - **Delete Old Orders**: Remove orders older than 30 days
   - **Export Filtered**: Export current filtered results
5. Edit or delete individual orders using the action buttons

### Data Management
1. Navigate to the "Settings" tab
2. **Backup Data**: Create JSON backups of all your data
3. **Restore Data**: Import previous backups
4. **Clear Data**: Remove all stored data
5. **Switch Themes**: Choose between Chinese and Modern themes
6. **View Statistics**: See data size and last backup information

### Exporting Data
1. Navigate to the "Export to Excel" tab
2. Choose export option:
   - **Export All Orders**: Download all orders
   - **Export Filtered Orders**: Download only filtered results
3. The Excel file will be automatically downloaded with proper formatting

### Keyboard Shortcuts
- `Ctrl + 1`: Switch to Add Order tab
- `Ctrl + 2`: Switch to Track Orders tab
- `Ctrl + 3`: Switch to Export tab
- `Ctrl + 4`: Switch to Settings tab
- `Ctrl + S`: Save current order (when form is valid)

## 🛠️ Technical Details

### Technologies Used
- **HTML5**: Semantic markup and structure
- **CSS3**: Modern styling with Flexbox and Grid
- **JavaScript (ES6+)**: Object-oriented programming with classes
- **SheetJS**: Excel file generation and export
- **Font Awesome**: Icons and visual elements
- **LocalStorage**: Client-side data persistence
- **Service Worker**: Offline functionality and caching

### Browser Compatibility
- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 12+
- ✅ Edge 79+

### Data Storage
- All data is stored locally in the browser's localStorage
- No server required - works completely offline
- Data persists between browser sessions
- Automatic backup functionality available
- JSON format for easy data portability

## 🔧 Customization

### Styling
The application supports two themes:

**Chinese Theme** (Default):
- Red-orange gradient background
- Traditional Chinese-inspired design
- Warm color palette

**Modern Theme**:
- Purple-blue gradient background
- Clean, modern design
- Professional color scheme

### Adding New Fields
To add new order fields:

1. **Update HTML form** in `index.html`
2. **Add validation** in `script.js` validateForm() method
3. **Update Excel export** in exportToExcel() method
4. **Modify table display** in renderOrders() method

### Extending Functionality
The modular JavaScript architecture makes it easy to extend:

```javascript
// Add new methods to KhataBook class
class KhataBook {
    // Your custom methods here
    customFunction() {
        // Implementation
    }
}
```

## 📱 Mobile Usage

The application is fully responsive and optimized for mobile devices:

- **Touch-friendly** buttons and form elements
- **Responsive tables** that scroll horizontally on small screens
- **Optimized layouts** for different screen sizes
- **Mobile-first** design approach
- **PWA support** for app-like experience

## 🔒 Security Considerations

### Data Protection
- All user inputs are sanitized to prevent XSS attacks
- Form validation prevents malicious data entry
- Local storage data is isolated to the browser
- No data is transmitted to external servers

### Best Practices
- Regular data backups using the export feature
- Keep browser updated for security patches
- Use private/incognito mode for sensitive data
- Backup important data regularly

## 🚨 Troubleshooting

### Common Issues

**Data not saving:**
- Check if localStorage is enabled in your browser
- Ensure sufficient storage space is available

**Excel export not working:**
- Verify internet connection (required for SheetJS library)
- Check browser console for error messages

**Form validation errors:**
- Ensure all required fields are filled
- Check date format and validity
- Verify amount fields contain valid numbers

**Theme not switching:**
- Clear browser cache and refresh
- Check if both theme CSS files are present

### Browser Console Errors
If you encounter JavaScript errors:
1. Open browser developer tools (F12)
2. Check the Console tab for error messages
3. Refresh the page and try again
4. Clear browser cache if issues persist

## 📈 Performance Tips

- **Large datasets**: Use filters to manage performance with many orders
- **Regular cleanup**: Export and delete old orders periodically
- **Browser optimization**: Keep browser updated for best performance
- **Offline mode**: Works without internet connection for better performance

## 🤝 Contributing

To contribute to this project:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is open source and available under the MIT License.

## 📞 Support

For support or questions:
- Check the troubleshooting section above
- Review browser console for error messages
- Ensure all files are in the same directory
- Verify browser compatibility
- Use the test page (`test.html`) to verify functionality

## 🔄 Version History

### Version 2.0.0 (Current)
- Added Settings tab with data management
- Implemented theme switching (Chinese/Modern)
- Added Quick Actions for bulk operations
- Enhanced backup and restore functionality
- Improved mobile responsiveness
- Added service worker for offline support
- Enhanced data validation and security

### Version 1.0.0
- Initial release
- Complete order management system
- Excel export functionality
- Responsive design
- Security features

---

**Made with ❤️ for small businesses**

*This digital khata book helps you manage customer orders efficiently and professionally.* 