// Digital Khata Book - Order Management System
class KhataBook {
    constructor() {
        this.orders = this.loadOrders();
        this.menuItems = this.loadMenuItems();
        this.currentFilters = {
            payment: '',
            delivery: '',
            search: ''
        };  
        this.selectedItems = [];
        this.foodOrderItems = []; // Added for food ordering system
        this.itemPrices = this.buildItemPrices();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupSettingsEventListeners();
        this.setupFoodOrderingEventListeners(); // Added
        this.setDefaultDate();
        this.updateStats();
        this.updateSettingsStats();
        this.renderOrders();
        this.renderMenuItems();
        this.renderFoodMenuGrid(); // Added
        this.populateItemSelect();
        this.setupSecurity();
        this.loadSavedTheme();
    }

    // Security Setup
    setupSecurity() {
        // Basic security: Prevent XSS attacks
        this.sanitizeInput = (input) => {
            const div = document.createElement('div');
            div.textContent = input;
            return div.innerHTML;
        };

        // Add CSRF protection token (simulated)
        this.csrfToken = this.generateCSRFToken();
    }

    generateCSRFToken() {
        return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    }

    // Data Management
    loadOrders() {
        try {
            const saved = localStorage.getItem('khataBookOrders');
            return saved ? JSON.parse(saved) : [];
        } catch (error) {
            console.error('Error loading orders:', error);
            return [];
        }
    }

    saveOrders() {
        try {
            localStorage.setItem('khataBookOrders', JSON.stringify(this.orders));
        } catch (error) {
            console.error('Error saving orders:', error);
            this.showMessage('Error saving data', 'error');
        }
    }

    // Event Listeners Setup
    setupEventListeners() {
        // Tab navigation
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });

        // Form submission
        document.getElementById('orderForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleOrderSubmission();
        });

        // Filters
        document.getElementById('paymentFilter').addEventListener('change', (e) => {
            this.currentFilters.payment = e.target.value;
            this.renderOrders();
        });

        document.getElementById('deliveryFilter').addEventListener('change', (e) => {
            this.currentFilters.delivery = e.target.value;
            this.renderOrders();
        });

        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.currentFilters.search = e.target.value.toLowerCase();
            this.renderOrders();
        });

        // Export buttons
        document.getElementById('exportAllBtn').addEventListener('click', () => {
            this.exportToExcel(this.orders);
        });

        document.getElementById('exportFilteredBtn').addEventListener('click', () => {
            const filteredOrders = this.getFilteredOrders();
            this.exportToExcel(filteredOrders);
        });

        // Item management
        document.getElementById('addItemBtn').addEventListener('click', () => {
            this.addItem();
        });

        // Quick actions
        document.getElementById('markAllPaidBtn').addEventListener('click', () => {
            this.markAllAsPaid();
        });

        document.getElementById('markAllDeliveredBtn').addEventListener('click', () => {
            this.markAllAsDelivered();
        });

        document.getElementById('deleteOldBtn').addEventListener('click', () => {
            this.deleteOldOrders();
        });

        // Modal events
        document.querySelector('.close').addEventListener('click', () => {
            this.closeEditModal();
        });

        document.getElementById('editForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleOrderUpdate();
        });

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeEditModal();
            }
        });
    }

    // Tab Navigation
    switchTab(tabName) {
        // Update active tab button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update active tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(tabName).classList.add('active');

        // Refresh data if switching to tracking tab
        if (tabName === 'order-tracking') {
            this.updateStats();
            this.renderOrders();
        }
    }

    // Form Validation
    validateForm(formData) {
        const errors = {};

        // Customer Name validation
        if (!formData.customerName.trim()) {
            errors.customerName = 'Customer name is required';
        } else if (formData.customerName.trim().length < 2) {
            errors.customerName = 'Customer name must be at least 2 characters';
        }

        // Order Details validation
        if (!formData.orderDetails.trim()) {
            errors.orderDetails = 'Order details are required';
        } else if (formData.orderDetails.trim().length < 10) {
            errors.orderDetails = 'Order details must be at least 10 characters';
        }

        // Order Date validation
        if (!formData.orderDate) {
            errors.orderDate = 'Order date is required';
        } else {
            const selectedDate = new Date(formData.orderDate);
            const today = new Date();
            if (selectedDate > today) {
                errors.orderDate = 'Order date cannot be in the future';
            }
        }

        // Payment Status validation
        if (!formData.paymentStatus) {
            errors.paymentStatus = 'Payment status is required';
        }

        // Delivery Status validation
        if (!formData.deliveryStatus) {
            errors.deliveryStatus = 'Delivery status is required';
        }

        // Amount validation (optional but if provided, must be valid)
        if (formData.orderAmount && (isNaN(formData.orderAmount) || parseFloat(formData.orderAmount) < 0)) {
            errors.orderAmount = 'Amount must be a valid positive number';
        }

        return errors;
    }

    // Display validation errors
    showValidationErrors(errors) {
        // Clear previous errors
        document.querySelectorAll('.error-message').forEach(error => {
            error.style.display = 'none';
            error.textContent = '';
        });

        // Show new errors
        Object.keys(errors).forEach(field => {
            const errorElement = document.getElementById(`${field}Error`);
            if (errorElement) {
                errorElement.textContent = errors[field];
                errorElement.style.display = 'block';
            }
        });
    }

    // Handle Order Submission
    handleOrderSubmission() {
        const form = document.getElementById('orderForm');
        const formData = new FormData(form);
        
        const orderData = {
            customerName: this.sanitizeInput(formData.get('customerName')),
            orderDetails: formData.get('orderDetails'),
            orderDate: formData.get('orderDate'),
            orderAmount: formData.get('orderAmount') || '0',
            paymentStatus: formData.get('paymentStatus'),
            deliveryStatus: formData.get('deliveryStatus'),
            items: [...this.selectedItems], // Include selected items
            createdAt: new Date().toISOString(),
            id: this.generateOrderId()
        };

        // Validate form data
        const errors = this.validateForm(orderData);
        if (Object.keys(errors).length > 0) {
            this.showValidationErrors(errors);
            return;
        }

        // Deduct quantities from menu items
        this.selectedItems.forEach(selectedItem => {
            const menuItem = this.menuItems.find(item => item.id === selectedItem.key);
            if (menuItem) {
                menuItem.quantity -= selectedItem.quantity;
                if (menuItem.quantity < 0) menuItem.quantity = 0;
            }
        });

        // Save updated menu items
        this.saveMenuItems();

        // Add order to storage
        this.orders.unshift(orderData);
        this.saveOrders();

        // Reset form and items
        form.reset();
        this.setDefaultDate();
        this.selectedItems = [];
        this.renderSelectedItems();
        this.updateBillSummary();

        // Clear validation errors
        this.showValidationErrors({});

        // Show success message
        this.showMessage('Order saved successfully!', 'success');

        // Update stats and switch to tracking tab
        this.updateStats();
        this.updateSettingsStats();
        this.renderMenuItems();
        this.switchTab('order-tracking');
    }

    // Generate unique order ID
    generateOrderId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    // Set default date to today
    setDefaultDate() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('orderDate').value = today;
    }

    // Get filtered orders
    getFilteredOrders() {
        return this.orders.filter(order => {
            const matchesPayment = !this.currentFilters.payment || order.paymentStatus === this.currentFilters.payment;
            const matchesDelivery = !this.currentFilters.delivery || order.deliveryStatus === this.currentFilters.delivery;
            const matchesSearch = !this.currentFilters.search || 
                order.customerName.toLowerCase().includes(this.currentFilters.search) ||
                order.orderDetails.toLowerCase().includes(this.currentFilters.search);

            return matchesPayment && matchesDelivery && matchesSearch;
        });
    }

    // Render orders table
    renderOrders() {
        const tbody = document.getElementById('ordersTableBody');
        const filteredOrders = this.getFilteredOrders();

        if (filteredOrders.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px; color: #666;">
                        <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 10px; display: block; opacity: 0.5;"></i>
                        No orders found
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = filteredOrders.map(order => `
            <tr>
                <td><strong>${order.customerName}</strong></td>
                <td>
                    ${order.orderDetails}
                    ${order.items && order.items.length > 0 ? `
                        <div style="margin-top: 8px; font-size: 0.9rem; color: #FF6347;">
                            <strong>Items:</strong>
                            ${order.items.map(item => `${item.name} (${item.quantity}x)`).join(', ')}
                        </div>
                    ` : ''}
                </td>
                <td>${this.formatDate(order.orderDate)}</td>
                <td>${order.orderAmount ? '₹' + parseFloat(order.orderAmount).toFixed(2) : '-'}</td>
                <td>
                    <span class="status-badge ${order.paymentStatus === 'Done' ? 'status-done' : 'status-pending'}">
                        ${order.paymentStatus}
                    </span>
                </td>
                <td>
                    <span class="status-badge ${order.deliveryStatus === 'Delivered' ? 'status-delivered' : 'status-pending'}">
                        ${order.deliveryStatus}
                    </span>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="khataBook.editOrder('${order.id}')">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="khataBook.deleteOrder('${order.id}')">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Update statistics
    updateStats() {
        const totalOrders = this.orders.length;
        const pendingPayments = this.orders.filter(order => order.paymentStatus === 'Pending').length;
        const pendingDeliveries = this.orders.filter(order => order.deliveryStatus === 'Pending').length;
        const completedOrders = this.orders.filter(order => 
            order.paymentStatus === 'Done' && order.deliveryStatus === 'Delivered'
        ).length;

        document.getElementById('totalOrders').textContent = totalOrders;
        document.getElementById('pendingPayments').textContent = pendingPayments;
        document.getElementById('pendingDeliveries').textContent = pendingDeliveries;
        document.getElementById('completedOrders').textContent = completedOrders;
    }

    // Edit order
    editOrder(orderId) {
        const order = this.orders.find(o => o.id === orderId);
        if (!order) return;

        // Populate modal with order data
        document.getElementById('editOrderId').value = order.id;
        document.getElementById('editCustomerName').value = order.customerName;
        document.getElementById('editOrderDetails').value = order.orderDetails;
        document.getElementById('editOrderDate').value = order.orderDate;
        document.getElementById('editOrderAmount').value = order.orderAmount;
        document.getElementById('editPaymentStatus').value = order.paymentStatus;
        document.getElementById('editDeliveryStatus').value = order.deliveryStatus;

        // Show modal
        document.getElementById('editModal').style.display = 'block';
    }

    // Handle order update
    handleOrderUpdate() {
        const orderId = document.getElementById('editOrderId').value;
        const orderIndex = this.orders.findIndex(o => o.id === orderId);
        
        if (orderIndex === -1) {
            this.showMessage('Order not found', 'error');
            return;
        }

        const updatedOrder = {
            ...this.orders[orderIndex],
            customerName: this.sanitizeInput(document.getElementById('editCustomerName').value),
            orderDetails: this.sanitizeInput(document.getElementById('editOrderDetails').value),
            orderDate: document.getElementById('editOrderDate').value,
            orderAmount: document.getElementById('editOrderAmount').value,
            paymentStatus: document.getElementById('editPaymentStatus').value,
            deliveryStatus: document.getElementById('editDeliveryStatus').value,
            updatedAt: new Date().toISOString()
        };

        // Validate updated data
        const errors = this.validateForm(updatedOrder);
        if (Object.keys(errors).length > 0) {
            this.showMessage('Please fix the validation errors', 'error');
            return;
        }

        // Update order
        this.orders[orderIndex] = updatedOrder;
        this.saveOrders();

        // Close modal
        this.closeEditModal();

        // Update display
        this.updateStats();
        this.renderOrders();

        this.showMessage('Order updated successfully!', 'success');
    }

    // Delete order
    deleteOrder(orderId) {
        if (!confirm('Are you sure you want to delete this order? This action cannot be undone.')) {
            return;
        }

        const orderIndex = this.orders.findIndex(o => o.id === orderId);
        if (orderIndex === -1) return;

        this.orders.splice(orderIndex, 1);
        this.saveOrders();

        this.updateStats();
        this.renderOrders();
        this.showMessage('Order deleted successfully!', 'success');
    }

    // Close edit modal
    closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
        document.getElementById('editForm').reset();
    }

    // Export to Excel
    exportToExcel(orders) {
        if (!orders || orders.length === 0) {
            this.showMessage('No orders to export', 'info');
            return;
        }

        try {
            // Prepare data for Excel
            const excelData = orders.map(order => ({
                'Customer Name': order.customerName,
                'Order Details': order.orderDetails,
                'Items': order.items && order.items.length > 0 ? 
                    order.items.map(item => `${item.name} (${item.quantity}x)`).join(', ') : '',
                'Order Date': this.formatDate(order.orderDate),
                'Order Amount': order.orderAmount ? parseFloat(order.orderAmount).toFixed(2) : '',
                'Payment Status': order.paymentStatus,
                'Delivery Status': order.deliveryStatus,
                'Created At': this.formatDate(order.createdAt),
                'Last Updated': order.updatedAt ? this.formatDate(order.updatedAt) : ''
            }));

            // Create workbook and worksheet
            const wb = XLSX.utils.book_new();
            const ws = XLSX.utils.json_to_sheet(excelData);

            // Set column widths
            const colWidths = [
                { wch: 20 }, // Customer Name
                { wch: 40 }, // Order Details
                { wch: 50 }, // Items
                { wch: 15 }, // Order Date
                { wch: 15 }, // Order Amount
                { wch: 15 }, // Payment Status
                { wch: 15 }, // Delivery Status
                { wch: 20 }, // Created At
                { wch: 20 }  // Last Updated
            ];
            ws['!cols'] = colWidths;

            // Add worksheet to workbook
            XLSX.utils.book_append_sheet(wb, ws, 'Orders');

            // Generate filename with timestamp
            const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
            const filename = `KhataBook_Orders_${timestamp}.xlsx`;

            // Save file
            XLSX.writeFile(wb, filename);

            this.showMessage(`Exported ${orders.length} orders to ${filename}`, 'success');
        } catch (error) {
            console.error('Export error:', error);
            this.showMessage('Error exporting to Excel', 'error');
        }
    }

    // Format date for display
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    // Show message
    showMessage(message, type = 'info') {
        const messageContainer = document.getElementById('messageContainer');
        const messageElement = document.createElement('div');
        messageElement.className = `message ${type}`;
        messageElement.textContent = message;

        messageContainer.appendChild(messageElement);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (messageElement.parentNode) {
                messageElement.parentNode.removeChild(messageElement);
            }
        }, 5000);
    }

    // Data backup and restore functionality
    backupData() {
        const backup = {
            orders: this.orders,
            timestamp: new Date().toISOString(),
            version: '1.0'
        };

        const dataStr = JSON.stringify(backup, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = `KhataBook_Backup_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`;
        link.click();
        
        URL.revokeObjectURL(url);
    }

    // Import data from backup
    importData(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const backup = JSON.parse(e.target.result);
                if (backup.orders && Array.isArray(backup.orders)) {
                    this.orders = backup.orders;
                    this.saveOrders();
                    this.updateStats();
                    this.renderOrders();
                    this.showMessage('Data imported successfully!', 'success');
                } else {
                    this.showMessage('Invalid backup file format', 'error');
                }
            } catch (error) {
                console.error('Import error:', error);
                this.showMessage('Error importing data', 'error');
            }
        };
        reader.readAsText(file);
    }

    // Item Management Methods
    addItem() {
        const itemSelect = document.getElementById('itemSelect');
        const quantityInput = document.getElementById('itemQuantity');
        
        if (!itemSelect.value) {
            this.showMessage('Please select an item', 'error');
            return;
        }

        const quantity = parseInt(quantityInput.value) || 1;
        const itemKey = itemSelect.value;
        const itemPrice = this.itemPrices[itemKey];
        const itemName = itemSelect.options[itemSelect.selectedIndex].text.split(' - ')[0];

        // Find the menu item to check stock
        const menuItem = this.menuItems.find(item => item.id === itemKey);
        if (!menuItem) {
            this.showMessage('Item not found in menu', 'error');
            return;
        }

        // Check if enough stock is available
        if (menuItem.quantity < quantity) {
            this.showMessage(`Only ${menuItem.quantity} items available in stock`, 'error');
            return;
        }

        // Check if item already exists
        const existingItemIndex = this.selectedItems.findIndex(item => item.key === itemKey);
        
        if (existingItemIndex !== -1) {
            // Check if adding more would exceed stock
            const newTotalQuantity = this.selectedItems[existingItemIndex].quantity + quantity;
            if (newTotalQuantity > menuItem.quantity) {
                this.showMessage(`Cannot add more than ${menuItem.quantity} items (${menuItem.quantity - this.selectedItems[existingItemIndex].quantity} remaining)`, 'error');
                return;
            }
            // Update quantity of existing item
            this.selectedItems[existingItemIndex].quantity += quantity;
        } else {
            // Add new item
            this.selectedItems.push({
                key: itemKey,
                name: itemName,
                price: itemPrice,
                quantity: quantity
            });
        }

        this.renderSelectedItems();
        this.updateBillSummary();
        
        // Reset inputs
        itemSelect.value = '';
        quantityInput.value = 1;
    }

    renderSelectedItems() {
        const container = document.getElementById('selectedItems');
        
        if (this.selectedItems.length === 0) {
            container.innerHTML = '<p style="color: #cccccc; text-align: center; padding: 20px;">No items selected</p>';
            return;
        }

        container.innerHTML = this.selectedItems.map((item, index) => `
            <div class="item-row">
                <div class="item-info">
                    <span class="item-name">${item.name}</span>
                    <div class="item-quantity">
                        <span>Qty:</span>
                        <div class="quantity-controls">
                            <button class="quantity-btn" onclick="khataBook.updateQuantity(${index}, -1)">-</button>
                            <span class="quantity-display">${item.quantity}</span>
                            <button class="quantity-btn" onclick="khataBook.updateQuantity(${index}, 1)">+</button>
                        </div>
                    </div>
                </div>
                <div class="item-price">₹${(item.price * item.quantity).toFixed(2)}</div>
                <button class="remove-item" onclick="khataBook.removeItem(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }

    updateQuantity(index, change) {
        const item = this.selectedItems[index];
        const newQuantity = item.quantity + change;
        
        if (newQuantity <= 0) {
            this.removeItem(index);
        } else {
            item.quantity = newQuantity;
            this.renderSelectedItems();
            this.updateBillSummary();
        }
    }

    removeItem(index) {
        this.selectedItems.splice(index, 1);
        this.renderSelectedItems();
        this.updateBillSummary();
    }

    updateBillSummary() {
        const subtotal = this.selectedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const tax = subtotal * 0.05; // 5% tax
        const total = subtotal + tax;

        document.getElementById('subtotal').textContent = `₹${subtotal.toFixed(2)}`;
        document.getElementById('tax').textContent = `₹${tax.toFixed(2)}`;
        document.getElementById('totalBill').innerHTML = `<strong>₹${total.toFixed(2)}</strong>`;
        
        // Update the order amount field
        document.getElementById('orderAmount').value = total.toFixed(2);
    }



    // Settings and Data Management Methods
    setupSettingsEventListeners() {
        // Backup functionality
        document.getElementById('backupBtn').addEventListener('click', () => {
            this.createBackup();
        });

        // Restore functionality
        document.getElementById('restoreFile').addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.restoreBackup(e.target.files[0]);
            }
        });

        // Clear all data
        document.getElementById('clearAllBtn').addEventListener('click', () => {
            this.clearAllData();
        });

        // Export backup
        document.getElementById('exportBackupBtn').addEventListener('click', () => {
            this.exportBackup();
        });

        // Theme switching
        document.querySelectorAll('input[name="theme"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.switchTheme(e.target.value);
            });
        });

        // Menu management
        document.getElementById('addMenuItemBtn').addEventListener('click', () => {
            this.addMenuItem();
        });
    }

    // Create backup
    createBackup() {
        try {
            const backup = {
                orders: this.orders,
                timestamp: new Date().toISOString(),
                version: '1.0',
                totalOrders: this.orders.length
            };

            const dataStr = JSON.stringify(backup, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(dataBlob);
            
            const link = document.createElement('a');
            link.href = url;
            link.download = `KhataBook_Backup_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`;
            link.click();
            
            URL.revokeObjectURL(url);

            // Update last backup time
            localStorage.setItem('lastBackup', new Date().toISOString());
            this.updateSettingsStats();

            this.showMessage('Backup created successfully!', 'success');
        } catch (error) {
            console.error('Backup error:', error);
            this.showMessage('Error creating backup', 'error');
        }
    }

    // Restore backup
    restoreBackup(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const backup = JSON.parse(e.target.result);
                if (backup.orders && Array.isArray(backup.orders)) {
                    if (confirm(`This will replace all current data with ${backup.orders.length} orders from the backup. Continue?`)) {
                        this.orders = backup.orders;
                        this.saveOrders();
                        this.updateStats();
                        this.renderOrders();
                        this.updateSettingsStats();
                        this.showMessage('Data restored successfully!', 'success');
                    }
                } else {
                    this.showMessage('Invalid backup file format', 'error');
                }
            } catch (error) {
                console.error('Restore error:', error);
                this.showMessage('Error restoring backup', 'error');
            }
        };
        reader.readAsText(file);
    }

    // Clear all data
    clearAllData() {
        if (confirm('Are you sure you want to delete ALL data? This action cannot be undone!')) {
            this.orders = [];
            this.saveOrders();
            this.updateStats();
            this.renderOrders();
            this.updateSettingsStats();
            this.showMessage('All data cleared successfully!', 'success');
        }
    }

    // Export backup
    exportBackup() {
        this.createBackup();
    }

    // Switch theme
    switchTheme(theme) {
        const currentTheme = document.querySelector('link[href*="theme"]');
        if (theme === 'modern') {
            // Load modern theme
            if (!document.querySelector('link[href*="modern-theme"]')) {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = 'modern-theme.css';
                document.head.appendChild(link);
            }
        } else {
            // Use Chinese theme (default)
            const modernTheme = document.querySelector('link[href*="modern-theme"]');
            if (modernTheme) {
                modernTheme.remove();
            }
        }
        
        localStorage.setItem('selectedTheme', theme);
        this.showMessage(`Theme switched to ${theme}`, 'info');
    }

    // Update settings statistics
    updateSettingsStats() {
        document.getElementById('settingsTotalOrders').textContent = this.orders.length;
        
        // Calculate data size
        const dataSize = new Blob([JSON.stringify(this.orders)]).size;
        const sizeInKB = (dataSize / 1024).toFixed(2);
        document.getElementById('dataSize').textContent = `${sizeInKB} KB`;
        
        // Get last backup time
        const lastBackup = localStorage.getItem('lastBackup');
        if (lastBackup) {
            const date = new Date(lastBackup);
            document.getElementById('lastBackup').textContent = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        } else {
            document.getElementById('lastBackup').textContent = 'Never';
        }
    }

    // Enhanced init method to include settings
    init() {
        this.setupEventListeners();
        this.setupSettingsEventListeners();
        this.setDefaultDate();
        this.updateStats();
        this.updateSettingsStats();
        this.renderOrders();
        this.renderMenuItems();
        this.populateItemSelect();
        this.setupSecurity();
        this.loadSavedTheme();
    }

    // Load saved theme
    loadSavedTheme() {
        const savedTheme = localStorage.getItem('selectedTheme');
        if (savedTheme && savedTheme !== 'chinese') {
            const radio = document.querySelector(`input[name="theme"][value="${savedTheme}"]`);
            if (radio) {
                radio.checked = true;
                this.switchTheme(savedTheme);
            }
        }
    }

    // Menu Management Methods
    loadMenuItems() {
        try {
            const saved = localStorage.getItem('khataBookMenuItems');
            return saved ? JSON.parse(saved) : this.getDefaultMenuItems();
        } catch (error) {
            console.error('Error loading menu items:', error);
            return this.getDefaultMenuItems();
        }
    }

    getDefaultMenuItems() {
        return [
            { id: 'manchurian', name: 'Manchurian', price: 210, quantity: 50 },
            { id: 'panner-chilly', name: 'Panner Chilly', price: 230, quantity: 30 },
            { id: 'chinese-bhel', name: 'Chinese Bhel', price: 210, quantity: 40 },
            { id: 'fried-rice', name: 'Fried Rice', price: 210, quantity: 60 },
            { id: 'popcorn', name: 'Popcorn', price: 80, quantity: 100 },
            { id: 'bhungla-pateta', name: 'Bhungla Pateta', price: 60, quantity: 25 },
            { id: 'dhokla', name: 'Dhokla', price: 90, quantity: 35 }
        ];
    }

    saveMenuItems() {
        try {
            localStorage.setItem('khataBookMenuItems', JSON.stringify(this.menuItems));
            this.itemPrices = this.buildItemPrices();
            this.populateItemSelect();
        } catch (error) {
            console.error('Error saving menu items:', error);
            this.showMessage('Error saving menu items', 'error');
        }
    }

    buildItemPrices() {
        const prices = {};
        this.menuItems.forEach(item => {
            prices[item.id] = item.price;
        });
        return prices;
    }

    populateItemSelect() {
        const itemSelect = document.getElementById('itemSelect');
        if (!itemSelect) return;

        // Clear existing options except the first one
        itemSelect.innerHTML = '<option value="">Choose an item...</option>';

        // Add all items without category grouping
        this.menuItems.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = `${item.name} - ₹${item.price}`;
            itemSelect.appendChild(option);
        });
    }

    renderMenuItems() {
        const container = document.getElementById('menuItemsContainer');
        if (!container) return;

        if (this.menuItems.length === 0) {
            container.innerHTML = '<p style="color: #cccccc; text-align: center; padding: 20px;">No menu items added yet</p>';
            return;
        }

        container.innerHTML = this.menuItems.map((item, index) => `
            <div class="menu-item">
                <div class="menu-item-info">
                    <div class="menu-item-name">${item.name}</div>
                    <div class="menu-item-details">
                        <span class="menu-item-price">₹${item.price}</span>
                        <span class="menu-item-quantity">Stock: ${item.quantity || 0}</span>
                    </div>
                </div>
                <div class="menu-item-actions">
                    <button class="btn btn-sm btn-primary" onclick="khataBook.editMenuItem(${index})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="khataBook.deleteMenuItem(${index})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `).join('');
    }

    addMenuItem() {
        const name = document.getElementById('newItemName').value.trim();
        const price = parseFloat(document.getElementById('newItemPrice').value);
        const quantity = parseInt(document.getElementById('newItemQuantity').value) || 0;

        if (!name) {
            this.showMessage('Please enter item name', 'error');
            return;
        }

        if (isNaN(price) || price <= 0) {
            this.showMessage('Please enter a valid price', 'error');
            return;
        }

        if (isNaN(quantity) || quantity < 0) {
            this.showMessage('Please enter a valid quantity', 'error');
            return;
        }

        // Check if item already exists
        const existingItem = this.menuItems.find(item => item.name.toLowerCase() === name.toLowerCase());
        if (existingItem) {
            this.showMessage('Item already exists', 'error');
            return;
        }

        // Add new item
        const newItem = {
            id: this.generateItemId(name),
            name: name,
            price: price,
            quantity: quantity
        };

        this.menuItems.push(newItem);
        this.saveMenuItems();
        this.renderMenuItems();
        this.renderFoodMenuGrid();

        // Clear form
        document.getElementById('newItemName').value = '';
        document.getElementById('newItemPrice').value = '';
        document.getElementById('newItemQuantity').value = '';

        this.showMessage('Menu item added successfully!', 'success');
    }

    editMenuItem(index) {
        const item = this.menuItems[index];
        
        const newName = prompt('Enter new name:', item.name);
        if (!newName || newName.trim() === '') return;

        const newPrice = prompt('Enter new price:', item.price);
        if (!newPrice || isNaN(newPrice) || parseFloat(newPrice) <= 0) return;

        const newQuantity = prompt('Enter new quantity (stock):', item.quantity || 0);
        if (!newQuantity || isNaN(newQuantity) || parseInt(newQuantity) < 0) return;

        // Update item
        this.menuItems[index] = {
            ...item,
            name: newName.trim(),
            price: parseFloat(newPrice),
            quantity: parseInt(newQuantity)
        };

        this.saveMenuItems();
        this.renderMenuItems();
        this.renderFoodMenuGrid();
        this.showMessage('Menu item updated successfully!', 'success');
    }

    deleteMenuItem(index) {
        const item = this.menuItems[index];
        if (!item) return;

        if (confirm(`Are you sure you want to delete "${item.name}" from the menu?`)) {
            this.menuItems.splice(index, 1);
            this.saveMenuItems();
            this.renderMenuItems();
            this.showMessage('Menu item deleted successfully!', 'success');
        }
    }

    generateItemId(name) {
        return name.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + Date.now().toString(36);
    }

    // Quick Actions
    markAllAsPaid() {
        if (confirm('Are you sure you want to mark all orders as "Done" (Paid)? This action cannot be undone.')) {
            this.orders.forEach(order => {
                if (order.paymentStatus !== 'Done') {
                    order.paymentStatus = 'Done';
                    order.updatedAt = new Date().toISOString();
                }
            });
            this.saveOrders();
            this.updateStats();
            this.renderOrders();
            this.showMessage('All orders marked as paid!', 'success');
        }
    }

    markAllAsDelivered() {
        if (confirm('Are you sure you want to mark all orders as "Delivered"? This action cannot be undone.')) {
            this.orders.forEach(order => {
                if (order.deliveryStatus !== 'Delivered') {
                    order.deliveryStatus = 'Delivered';
                    order.updatedAt = new Date().toISOString();
                }
            });
            this.saveOrders();
            this.updateStats();
            this.renderOrders();
            this.showMessage('All orders marked as delivered!', 'success');
        }
    }

    deleteOldOrders() {
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const ordersToDelete = this.orders.filter(order => new Date(order.createdAt) < thirtyDaysAgo);

        if (ordersToDelete.length === 0) {
            this.showMessage('No orders older than 30 days to delete.', 'info');
            return;
        }

        if (confirm(`Are you sure you want to delete ${ordersToDelete.length} orders older than 30 days? This action cannot be undone.`)) {
            this.orders = this.orders.filter(order => new Date(order.createdAt) >= thirtyDaysAgo);
            this.saveOrders();
            this.updateStats();
            this.renderOrders();
            this.showMessage(`Deleted ${ordersToDelete.length} old orders.`, 'success');
        }
    }

    // Food Ordering System Methods
    setupFoodOrderingEventListeners() {
        // Menu search
        document.getElementById('menuSearch')?.addEventListener('input', (e) => {
            this.filterFoodMenu();
        });

        // Clear order button
        document.getElementById('clearOrderBtn')?.addEventListener('click', () => {
            this.clearFoodOrder();
        });

        // Feedback button
        document.getElementById('feedbackBtn')?.addEventListener('click', () => {
            this.showFeedbackModal();
        });

        // Confirm order button
        document.getElementById('confirmOrderBtn')?.addEventListener('click', () => {
            this.showOrderConfirmation();
        });

        // Rating stars
        document.querySelectorAll('.star')?.forEach(star => {
            star.addEventListener('click', (e) => {
                this.setRating(parseInt(e.target.dataset.rating));
            });
        });

        // Set default date for food ordering
        this.setFoodOrderDefaultDate();
    }

    setFoodOrderDefaultDate() {
        const foodOrderDate = document.getElementById('foodOrderDate');
        if (foodOrderDate) {
            const today = new Date().toISOString().split('T')[0];
            foodOrderDate.value = today;
        }
    }

    renderFoodMenuGrid() {
        const container = document.getElementById('menuGrid');
        if (!container) return;

        if (this.menuItems.length === 0) {
            container.innerHTML = `
                <div class="empty-menu">
                    <i class="fas fa-utensils"></i>
                    <h3>No Menu Items Available</h3>
                    <p>Add some menu items in the Settings tab to get started.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.menuItems.map((item, index) => `
            <div class="menu-item-card ${item.quantity <= 0 ? 'out-of-stock' : ''}" data-name="${item.name.toLowerCase()}">
                <div class="menu-item-header">
                    <h3 class="menu-item-name">${item.name}</h3>
                    <span class="menu-item-price">₹${item.price}</span>
                </div>
                <div class="menu-item-stock">
                    <i class="fas fa-box"></i> Stock: ${item.quantity || 0} available
                </div>
                <div class="menu-item-actions">
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="khataBook.updateFoodItemQuantity(${index}, -1)" ${item.quantity <= 0 ? 'disabled' : ''}>-</button>
                        <span class="quantity-display" id="foodQuantity-${index}">0</span>
                        <button class="quantity-btn" onclick="khataBook.updateFoodItemQuantity(${index}, 1)" ${item.quantity <= 0 ? 'disabled' : ''}>+</button>
                    </div>
                    <button class="add-to-order-btn" onclick="khataBook.addFoodItemToOrder(${index})" ${item.quantity <= 0 ? 'disabled' : ''}>
                        <i class="fas fa-plus"></i> Add to Order
                    </button>
                </div>
            </div>
        `).join('');
    }

    filterFoodMenu() {
        const searchTerm = document.getElementById('menuSearch')?.value.toLowerCase() || '';
        const menuCards = document.querySelectorAll('.menu-item-card');

        menuCards.forEach(card => {
            const name = card.dataset.name;
            const searchMatch = !searchTerm || name.includes(searchTerm);

            if (searchMatch) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }

    updateFoodItemQuantity(itemIndex, change) {
        const quantityDisplay = document.getElementById(`foodQuantity-${itemIndex}`);
        if (!quantityDisplay) return;

        let currentQuantity = parseInt(quantityDisplay.textContent) || 0;
        const newQuantity = Math.max(0, currentQuantity + change);
        
        quantityDisplay.textContent = newQuantity;
    }

    addFoodItemToOrder(itemIndex) {
        const item = this.menuItems[itemIndex];
        const quantityDisplay = document.getElementById(`foodQuantity-${itemIndex}`);
        const quantity = parseInt(quantityDisplay.textContent) || 0;

        if (quantity <= 0) {
            this.showMessage('Please select a quantity first', 'error');
            return;
        }

        if (quantity > item.quantity) {
            this.showMessage(`Only ${item.quantity} items available in stock`, 'error');
            return;
        }

        // Check if item already exists in food order
        const existingItemIndex = this.foodOrderItems.findIndex(orderItem => orderItem.id === item.id);
        
        if (existingItemIndex !== -1) {
            // Update quantity of existing item
            this.foodOrderItems[existingItemIndex].quantity += quantity;
        } else {
            // Add new item
            this.foodOrderItems.push({
                id: item.id,
                name: item.name,
                price: item.price,
                quantity: quantity
            });
        }

        // Reset quantity display
        quantityDisplay.textContent = '0';
        
        // Update order summary
        this.renderFoodOrderSummary();
        this.updateFoodOrderTotals();
        
        this.showMessage(`${quantity}x ${item.name} added to order`, 'success');
    }

    renderFoodOrderSummary() {
        const container = document.querySelector('.selected-items-list');
        if (!container) return;

        if (this.foodOrderItems.length === 0) {
            container.innerHTML = `
                <div class="empty-order">
                    <i class="fas fa-shopping-cart"></i>
                    <h4>No Items Selected</h4>
                    <p>Select items from the menu above to build your order.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.foodOrderItems.map((item, index) => `
            <div class="selected-item">
                <div class="selected-item-info">
                    <div class="selected-item-name">${item.name}</div>
                    <div class="selected-item-details">
                        <span>₹${item.price} each</span>
                    </div>
                </div>
                <div class="selected-item-quantity">
                    <span>Qty:</span>
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="khataBook.updateFoodOrderQuantity(${index}, -1)">-</button>
                        <span class="quantity-display">${item.quantity}</span>
                        <button class="quantity-btn" onclick="khataBook.updateFoodOrderQuantity(${index}, 1)">+</button>
                    </div>
                </div>
                <div class="selected-item-total">₹${(item.price * item.quantity).toFixed(2)}</div>
                <button class="remove-item" onclick="khataBook.removeFoodOrderItem(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }

    updateFoodOrderQuantity(itemIndex, change) {
        const item = this.foodOrderItems[itemIndex];
        const newQuantity = item.quantity + change;
        
        if (newQuantity <= 0) {
            this.removeFoodOrderItem(itemIndex);
        } else {
            // Check stock availability
            const menuItem = this.menuItems.find(menuItem => menuItem.id === item.id);
            if (menuItem && newQuantity > menuItem.quantity) {
                this.showMessage(`Only ${menuItem.quantity} items available in stock`, 'error');
                return;
            }
            
            item.quantity = newQuantity;
            this.renderFoodOrderSummary();
            this.updateFoodOrderTotals();
        }
    }

    removeFoodOrderItem(itemIndex) {
        this.foodOrderItems.splice(itemIndex, 1);
        this.renderFoodOrderSummary();
        this.updateFoodOrderTotals();
    }

    updateFoodOrderTotals() {
        const total = this.foodOrderItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        document.getElementById('foodSubtotal').textContent = `₹${total.toFixed(2)}`;
        document.getElementById('foodTax').textContent = `₹0.00`;
        document.getElementById('foodGrandTotal').innerHTML = `<strong>₹${total.toFixed(2)}</strong>`;
    }

    clearFoodOrder() {
        if (this.foodOrderItems.length === 0) {
            this.showMessage('No items to clear', 'info');
            return;
        }

        if (confirm('Are you sure you want to clear the entire order?')) {
            this.foodOrderItems = [];
            this.renderFoodOrderSummary();
            this.updateFoodOrderTotals();
            
            // Reset all quantity displays
            this.menuItems.forEach((item, index) => {
                const quantityDisplay = document.getElementById(`foodQuantity-${index}`);
                if (quantityDisplay) {
                    quantityDisplay.textContent = '0';
                }
            });
            
            this.showMessage('Order cleared successfully', 'success');
        }
    }

    showOrderConfirmation() {
        const customerName = document.getElementById('foodCustomerName')?.value.trim();
        const orderDate = document.getElementById('foodOrderDate')?.value;

        if (!customerName) {
            this.showMessage('Please enter customer name', 'error');
            return;
        }

        if (!orderDate) {
            this.showMessage('Please select order date', 'error');
            return;
        }

        if (this.foodOrderItems.length === 0) {
            this.showMessage('Please add items to the order', 'error');
            return;
        }

        const total = this.foodOrderItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        const confirmationDetails = document.getElementById('confirmationDetails');
        confirmationDetails.innerHTML = `
            <div class="confirmation-section">
                <h4><i class="fas fa-user"></i> Customer Details</h4>
                <p><strong>Name:</strong> ${customerName}</p>
                <p><strong>Date:</strong> ${this.formatDate(orderDate)}</p>
            </div>
            
            <div class="confirmation-section">
                <h4><i class="fas fa-list"></i> Order Items</h4>
                ${this.foodOrderItems.map(item => `
                    <div class="confirmation-item">
                        <span>${item.name} x${item.quantity}</span>
                        <span>₹${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            
            <div class="confirmation-section">
                <h4><i class="fas fa-calculator"></i> Order Summary</h4>
                <div class="confirmation-totals">
                    <div class="confirmation-row total">
                        <span><strong>Total Amount:</strong></span>
                        <span><strong>₹${total.toFixed(2)}</strong></span>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('orderConfirmationModal').style.display = 'block';
    }

    closeOrderConfirmation() {
        document.getElementById('orderConfirmationModal').style.display = 'none';
    }

    finalizeOrder() {
        const customerName = document.getElementById('foodCustomerName').value.trim();
        const orderDate = document.getElementById('foodOrderDate').value;
        const subtotal = this.foodOrderItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const tax = subtotal * 0.05;
        const total = subtotal + tax;

        // Create order details string
        const orderDetails = this.foodOrderItems.map(item => 
            `${item.name} x${item.quantity}`
        ).join(', ');

        // Create order data
        const orderData = {
            customerName: this.sanitizeInput(customerName),
            orderDetails: orderDetails,
            orderDate: orderDate,
            orderAmount: total.toFixed(2),
            paymentStatus: 'Pending',
            deliveryStatus: 'Pending',
            items: [...this.foodOrderItems],
            createdAt: new Date().toISOString(),
            id: this.generateOrderId()
        };

        // Deduct quantities from menu items
        this.foodOrderItems.forEach(orderItem => {
            const menuItem = this.menuItems.find(item => item.id === orderItem.id);
            if (menuItem) {
                menuItem.quantity -= orderItem.quantity;
                if (menuItem.quantity < 0) menuItem.quantity = 0;
            }
        });

        // Save updated menu items
        this.saveMenuItems();

        // Add order to storage
        this.orders.unshift(orderData);
        this.saveOrders();

        // Reset food ordering form
        this.clearFoodOrder();
        document.getElementById('foodCustomerName').value = '';
        this.setFoodOrderDefaultDate();

        // Close modal
        this.closeOrderConfirmation();

        // Show success message
        this.showMessage('Order saved successfully!', 'success');

        // Update stats and switch to tracking tab
        this.updateStats();
        this.updateSettingsStats();
        this.renderMenuItems();
        this.renderFoodMenuGrid();
        this.switchTab('order-tracking');
    }

    // Feedback System
    setRating(rating) {
        document.querySelectorAll('.star').forEach((star, index) => {
            if (index < rating) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
        this.currentRating = rating;
    }

    showFeedbackModal() {
        document.getElementById('feedbackModal').style.display = 'block';
        this.currentRating = 0;
        document.querySelectorAll('.star').forEach(star => star.classList.remove('active'));
        document.getElementById('feedbackComment').value = '';
    }

    closeFeedbackModal() {
        document.getElementById('feedbackModal').style.display = 'none';
    }

    submitFeedback() {
        const rating = this.currentRating || 0;
        const comment = document.getElementById('feedbackComment').value.trim();

        if (rating === 0) {
            this.showMessage('Please select a rating', 'error');
            return;
        }

        // Save feedback to localStorage
        const feedback = {
            rating: rating,
            comment: comment,
            timestamp: new Date().toISOString(),
            feature: 'Food Ordering System'
        };

        const existingFeedback = JSON.parse(localStorage.getItem('khataBookFeedback') || '[]');
        existingFeedback.push(feedback);
        localStorage.setItem('khataBookFeedback', JSON.stringify(existingFeedback));

        this.closeFeedbackModal();
        this.showMessage('Thank you for your feedback!', 'success');
    }
}

// Initialize the application
let khataBook;

// Global function for edit modal (accessible from HTML)
function closeEditModal() {
    if (khataBook) {
        khataBook.closeEditModal();
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    khataBook = new KhataBook();
});

// Add keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
            case '1':
                e.preventDefault();
                khataBook.switchTab('order-form');
                break;
            case '2':
                e.preventDefault();
                khataBook.switchTab('order-tracking');
                break;
            case '3':
                e.preventDefault();
                khataBook.switchTab('export');
                break;
            case '4':
                e.preventDefault();
                khataBook.switchTab('settings');
                break;
            case 's':
                e.preventDefault();
                if (document.getElementById('orderForm').checkValidity()) {
                    khataBook.handleOrderSubmission();
                }
                break;
        }
    }
});

// Add service worker for offline functionality (basic implementation)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}