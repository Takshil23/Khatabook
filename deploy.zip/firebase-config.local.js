// Optional Firebase config for multi-user sync.
// Fill with your Firebase keys to enable Firestore; otherwise localStorage fallback will be used.
// Example:
// window.FIREBASE_CONFIG = {
//   apiKey: "...",
//   authDomain: "...",
//   projectId: "...",
//   storageBucket: "...",
//   messagingSenderId: "...",
//   appId: "..."
// };
